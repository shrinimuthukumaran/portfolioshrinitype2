document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.getElementById('menu-toggle');
    const menuLinks = document.querySelector('.menu-links');

    menuToggle.addEventListener('click', function () {
        menuLinks.classList.toggle('active');
    });
});

function openTab(tabName) {
    var i;
    var x = document.getElementsByClassName("tab-contents");
    var tabLinks = document.getElementsByClassName("tab-links");

    for (i = 0; i < x.length; i++) {
        x[i].classList.remove("active-tab");
    }
    
    for (i = 0; i < tabLinks.length; i++) {
        tabLinks[i].classList.remove("active-link");
    }

    document.getElementById(tabName).classList.add("active-tab");
    event.currentTarget.classList.add("active-link");
}

